package edu.eci.arsw.threads;
import edu.eci.arsw.blacklistvalidator.HostBlackListsValidator;
import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;

import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicInteger;

public class HostBlackListsThread extends Thread {
    public static AtomicInteger countApparences = new AtomicInteger();
    private String ipAddress;
    private int start;
    private int end;
    private HostBlacklistsDataSourceFacade skds;

    public HostBlackListsThread(String ipAddress, int start, int end, HostBlacklistsDataSourceFacade skds) {
        this.ipAddress = ipAddress;
        this.start = start;
        this.end = end;
        this.skds = skds;
    }

    LinkedList<Integer> blackListOcurrences=new LinkedList<>();
    int checkedListsCount=0;

    @Override
    public void run() {
        for (int i = start; i < end && countApparences.get() < HostBlackListsValidator.BLACK_LIST_ALARM_COUNT; i++) {
            checkedListsCount++;
            if (skds.isInBlackListServer(i, ipAddress)) {
                int currentCount = countApparences.getAndIncrement();
                if (currentCount < HostBlackListsValidator.BLACK_LIST_ALARM_COUNT) {
                    blackListOcurrences.add(i);
                }
            }
        }
    }


    public int getCheckedListsCount() {
        return checkedListsCount;
    }

    public LinkedList<Integer> getBlackListOcurrences() {
        return blackListOcurrences;
    }
}
